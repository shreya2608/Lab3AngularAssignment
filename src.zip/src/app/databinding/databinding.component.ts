import { Component,OnInit } from '@angular/core';


@Component({
  selector: 'app-databinding',
  templateUrl: './databinding.component.html',
  styleUrls: ['./databinding.component.css']
})
export class DatabindingComponent implements OnInit{
  Username:string='';
  count:number=0;
  numbers:number[]=[]
  ngOnInit() {
    console.log('init databinding');
  }
  onclick(){
    this.Username='';
  }
  isDisabled(){
    if (this.Username==''){
      return true;
    }
    else{
      return false;
    }
  }
  displayDetails() {
    this.count=this.count+1;
    this.numbers.push(this.count);
  }
  getColor()

  {

    return 'blue';

  }
}
